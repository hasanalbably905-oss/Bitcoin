'use strict';
// No HTML-injection sinks and no inline handlers anywhere: everything the server sends is shown with textContent only.
(function () {
  var NAMES = { SENDS: 'إرسال المعاملات', RELEASES: 'تحديثات التطبيق', SERVICE: 'الخدمة بالكامل' };
  var enc = new TextEncoder();
  var st = { key: null, enc: null, keyId: '', poll: null, idle: null };
  var $ = function (id) { return document.getElementById(id); };

  function hex(buf) {
    return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = String(text);
    return e;
  }
  function say(msg, bad) { var m = $('msg'); m.textContent = msg || ''; m.className = bad ? 'msg bad' : 'msg'; }
  function button(label, action, cls, fn) {
    var b = el('button', cls || '', label);
    b.setAttribute('type', 'button');
    b.setAttribute('data-action', action);
    b.addEventListener('click', fn);
    return b;
  }

  // End-to-end envelope (AES-256-GCM, key derived with HKDF from the same secret): TLS proxies only see ciphertext.
  function b64u(buf) { var a = new Uint8Array(buf), s = ''; for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64u(str) { var s = atob(str.replace(/-/g, '+').replace(/_/g, '/')), a = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
  async function seal(plain, aad) {
    var iv = crypto.getRandomValues(new Uint8Array(12));
    var out = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv, additionalData: enc.encode(aad) }, st.enc, enc.encode(plain)));
    return 'v1.e.' + b64u(iv) + '.' + b64u(out.slice(0, out.length - 16)) + '.' + b64u(out.slice(out.length - 16));
  }
  async function unseal(sealed, aad) {
    var p = String(sealed).split('.');
    if (p.length !== 5 || p[0] !== 'v1' || p[1] !== 'e') throw new Error('bad_envelope');
    var ct = unb64u(p[3]), tag = unb64u(p[4]), joined = new Uint8Array(ct.length + tag.length);
    joined.set(ct, 0); joined.set(tag, ct.length);
    return new TextDecoder().decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64u(p[2]), additionalData: enc.encode(aad) }, st.enc, joined));
  }

  // Requests are signed in the browser (HMAC-SHA256); the key is a non-extractable CryptoKey held in memory only.
  async function api(method, path, payload) {
    var plain = payload === undefined ? '' : JSON.stringify(payload);
    var ts = Date.now();
    var nonce = hex(crypto.getRandomValues(new Uint8Array(16)));
    var route = method + ' ' + path;
    var body = plain ? await seal(plain, 'req|' + route + '|' + ts + '|' + nonce) : '';
    var sig = hex(await crypto.subtle.sign('HMAC', st.key, enc.encode(ts + '.' + nonce + '.' + method + ' ' + path + '.' + body)));
    var res = await fetch(path, {
      method: method, body: method === 'GET' ? undefined : body, credentials: 'omit', cache: 'no-store',
      headers: { 'x-key-id': st.keyId, 'x-ts': String(ts), 'x-nonce': nonce, 'x-sig': sig, 'x-enc': '1' }
    });
    var json = {};
    try { json = await res.json(); if (json.enc) json = JSON.parse(await unseal(json.enc, 'res|' + route + '|' + nonce)); } catch (e) { json = {}; }
    if (!res.ok) throw new Error(json.error || ('HTTP ' + res.status));
    return json;
  }

  function lock(reason) {
    st.key = null; st.enc = null; st.keyId = '';
    clearInterval(st.poll); clearTimeout(st.idle);
    $('secret').value = '';
    $('app').hidden = true; $('login').hidden = false;
    ['breakers', 'pending', 'incidents', 'audit'].forEach(function (id) { $(id).replaceChildren(); });
    say(reason || '', false);
  }
  function touch() {
    clearTimeout(st.idle);
    st.idle = setTimeout(function () { lock('تم القفل تلقائيًا لعدم النشاط'); }, 5 * 60 * 1000);
  }

  async function act(body) {
    try {
      var r = await api('POST', '/actions', body);
      say(r && r.done === false ? 'تم تسجيل الطلب، بانتظار موافقة إضافية' : 'تم', false);
      await refresh(); touch();
    } catch (e) { say('فشل: ' + e.message, true); }
  }
  function toggle(name, frozen) {
    if (name === 'SERVICE' && frozen) { if (prompt('اكتب STOP لتأكيد إيقاف الخدمة بالكامل') !== 'STOP') return; }
    else if (!confirm((frozen ? 'تجميد: ' : 'إعادة تشغيل: ') + NAMES[name] + '؟')) return;
    return act({ op: 'propose', name: name, frozen: frozen });
  }

  function render(state, audit) {
    var br = $('breakers'); br.replaceChildren();
    ['SENDS', 'RELEASES', 'SERVICE'].forEach(function (n) {
      var frozen = !!state.breakers[n];
      var c = el('div', 'card' + (frozen ? ' critical' : ''));
      var row = el('div', 'row');
      row.append(el('b', '', NAMES[n]), el('span', 'pill ' + (frozen ? 'frozen' : 'ok'), frozen ? 'مجمّد' : 'يعمل'));
      c.append(row, button(frozen ? 'إعادة التشغيل (يحتاج موافقتين بينهم المالك)' : (n === 'SERVICE' ? 'إيقاف كامل (موافقتان)' : 'تجميد'),
        (frozen ? 'resume:' : 'freeze:') + n, frozen ? '' : 'danger', function () { return toggle(n, !frozen); }));
      br.append(c);
    });

    var pe = $('pending'); pe.replaceChildren();
    (state.pending || []).forEach(function (p) {
      var c = el('div', 'card');
      c.append(el('b', '', (p.frozen ? 'تجميد: ' : 'إعادة تشغيل: ') + (NAMES[p.name] || p.name)),
        el('span', 'muted', 'الموافقات ' + p.approvals.length + ' من ' + p.needed + ' — ' + p.approvals.join(', ')));
      if (p.approvals.indexOf(st.keyId) === -1) c.append(button('موافقة', 'approve:' + p.id, 'danger', function () { return act({ op: 'approve', id: p.id }); }));
      pe.append(c);
    });
    if (!pe.children.length) pe.append(el('span', 'muted', 'لا توجد طلبات'));

    var inc = $('incidents'); inc.replaceChildren();
    (state.incidents || []).slice().sort(function (a, b) { return b.createdAt - a.createdAt; }).forEach(function (i) {
      var f = i.findings[0] || {};
      var c = el('div', 'card' + (i.severity === 'critical' ? ' critical' : ''));
      var row = el('div', 'row');
      row.append(el('b', '', f.title || i.id), el('span', 'pill ' + i.severity, i.severity === 'critical' ? 'حرج' : 'تحذير'));
      c.append(row, el('div', 'pre', f.detail || ''));
      if (i.findings.length > 1) c.append(el('span', 'muted', '+' + (i.findings.length - 1) + ' نتائج أخرى'));
      if (i.aiSummary) c.append(el('span', 'muted', 'تحليل الذكاء الاصطناعي (استشاري)'), el('div', 'pre', i.aiSummary));
      c.append(el('span', 'muted', new Date(i.createdAt).toLocaleString('ar') + ' · ' + i.status));
      var acts = el('div', 'actions');
      if (i.status === 'open') acts.append(button('تأكيد الاستلام', 'ack:' + i.id, '', function () { return act({ op: 'ack', id: i.id }); }));
      acts.append(button('إغلاق', 'close:' + i.id, '', function () { return act({ op: 'close', id: i.id }); }));
      c.append(acts);
      inc.append(c);
    });
    if (!inc.children.length) inc.append(el('span', 'muted', 'لا توجد حوادث مفتوحة'));

    var au = $('audit'); au.replaceChildren();
    (audit.entries || []).slice().reverse().forEach(function (e) {
      au.append(el('div', 'audit', new Date(e.ts).toLocaleString('ar') + ' — ' + JSON.stringify(e.entry).slice(0, 300)));
    });
  }

  async function refresh() {
    var r = await Promise.all([
      api('GET', '/state'),
      api('GET', '/audit').catch(function (e) { if (e.message === 'not_found') return { entries: [] }; throw e; })
    ]);
    render(r[0], r[1]);
  }

  async function login() {
    var id = $('key-id').value.trim(); var secret = $('secret').value;
    if (!id || secret.length < 32) { say('أدخل المعرّف والمفتاح (32 حرفًا على الأقل)', true); return; }
    try {
      var raw = enc.encode(secret);
      st.key = await crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
      var base = await crypto.subtle.importKey('raw', raw, 'HKDF', false, ['deriveKey']);
      st.enc = await crypto.subtle.deriveKey({ name: 'HKDF', hash: 'SHA-256', salt: enc.encode('guardian-e2e-salt-v1'), info: enc.encode('guardian/e2e/v1') },
        base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
      raw.fill(0);
      st.keyId = id; $('secret').value = '';
      await refresh(); // a 401 here means wrong id/key
      $('login').hidden = true; $('app').hidden = false; $('who').textContent = id;
      say('', false);
      st.poll = setInterval(function () { refresh().catch(function (e) { lock('انتهت الجلسة: ' + e.message); }); }, 5000);
      touch();
    } catch (e) {
      st.key = null; st.enc = null; st.keyId = '';
      say(e.message === 'unauthorized' ? 'المعرّف أو المفتاح غير صحيح' : 'تعذر الدخول: ' + e.message, true);
    }
  }

  $('login-btn').addEventListener('click', login);
  $('secret').addEventListener('keydown', function (e) { if (e.key === 'Enter') login(); });
  $('lock-btn').addEventListener('click', function () { lock('تم القفل'); });
  ['click', 'keydown', 'touchstart', 'mousemove'].forEach(function (t) { document.addEventListener(t, function () { if (st.key) touch(); }); });
})();
