# guardian

Continuous security monitoring for a wallet backend: rules + anomaly detection, owner alerts that
ring like an alarm, and circuit breakers with approval rules. AI summarises incidents but never acts.

## Flow
events (api, ci, admin, sensors) -> rules + anomaly baseline -> incident -> push to owner (FCM)
+ backup channel -> owner taps Freeze / Stop in the app -> breaker enforced by your API.

## Safety design
- **AI is advisory.** `ClaudeAnalyzer` writes a summary onto the incident. It cannot trigger breakers, and event data is
  treated as untrusted (prompt-injection defence). The alert is sent *before* the AI runs.
- **No auto-shutdown.** Humans decide. Freeze = 1 approver. Full stop = 2 distinct people. Resume = 2 people incl. an owner.
- **Breakers are levels**: `SENDS`, `RELEASES`, `SERVICE`. Your API must check the flag on every sensitive request.
- **Heartbeat**: a source in `expectedSources` that goes quiet raises an incident (attacker muting logs).
- **Escalation**: unacknowledged critical incidents are re-sent every 2 min on all channels until someone acks.
- **Signed requests**: HMAC + timestamp + nonce replay protection. Service keys cannot act as humans.
- Anomaly baseline never learns from anomalous values (baseline poisoning).

## Rules included
brute force (single + distributed), admin created/role change/MFA off, off-hours admin login, unapproved or unsigned
release, API integrity mismatch (wrong address/fee returned), leaked secret / API key from new IP, physical tamper, fee spike,
metric anomalies, silent sources.

## Owner app (your mobile team)
1. Register the FCM token: `POST /devices {"token": "..."}` (signed as the owner).
2. Android: create notification channel `security-alarm`, importance HIGH, alarm sound, bypass DND if the user allows,
   full-screen intent so the alarm screen opens over the lock screen.
3. iOS: `interruption-level: time-sensitive` works by default. True critical alerts (bypass silent mode) need Apple's
   Critical Alerts entitlement; then set `criticalAlerts: true`.
4. On a `security_alarm` data message open the alarm screen. Fetch `GET /state` for details and the AI summary, and
   show buttons: Ignore (`ack`) / Freeze (`propose`) / Stop (`propose`, then a second person `approve`s).
5. Keep a backup channel (`telegram(...)`) because push can fail.

## Instagram
Not recommended. Meta's Instagram messaging API only lets a professional account reply within 24 hours after the
other person messaged it; there is no cold outreach, so an alert to yourself can silently fail.

## Run
`npm install && npm test` (the core runs with zero dependencies on Node 22.18+). `src/main.ts` is example wiring.

## Before production
Run it on separate infrastructure and a separate cloud account from the app it watches; store keys in a secret manager;
back `DeviceStore` and incidents with a database; test breakers with a drill; get a security review.
`FcmNotifier`, `ClaudeAnalyzer` and `main.ts` need real credentials and were not run here.

## Added: API integration and owner app
- `src/client.ts` (tested): `createFrozenGuard(flags).middleware('SERVICE')` (where `flags` is the authenticated `FlagStore` instance) returns 503 when frozen and fails closed if the flag
  cannot be read; `GuardianReporter.emit(...)` / `heartbeat(...)` send signed events from your services.
- `owner-app/` (NOT tested, needs React Native, Notifee, Firebase and @noble/hashes): `guardianClient.ts` (signed API calls),
  `alarm.ts` (looping alarm notification channel, full-screen), `AlarmScreen.tsx` (matches the design).
- Wire-up in your API: call `guard.assertNotFrozen('SENDS')` before any broadcast; `'RELEASES'` before publishing an update.

## Using a gateway (e.g. OmniRoute) for AI summaries
Set `ANALYZER_PROVIDER=openai-compatible`, `ANALYZER_BASE_URL` (https, or http on localhost), `ANALYZER_API_KEY`, `ANALYZER_MODEL`.
Gateway mode is treated as third party: only findings are sent (never raw events), IPs/emails/addresses/long secrets are masked,
redirects are refused, output is capped. Summaries stay advisory. For the Anthropic SDK through a compatible gateway use
`ANALYZER_BASE_URL` without the trailing `/v1`. Never route wallet secrets or user data through free third-party providers.

## Encryption map
| Data | Where | How |
|---|---|---|
| Traffic to the Guardian API | network | TLS 1.3 only (direct, tested) or your TLS proxy + `TRUST_PROXY=1`; HSTS; HTTP refused |
| Request authenticity | every request | HMAC-SHA256 + timestamp + nonce (replay-proof) |
| Owner phone tokens, incidents | `STATE_DIR` | AES-256-GCM, 0600 files, bound to file name, atomic writes, key rotation (`store.rotate()`) |
| Audit log | `audit.log` | encrypted + hash-chained; tampering detected at startup (Guardian refuses to start) |
| Secrets (keys, tokens) | env | prefer `NAME_FILE` secret files; never logged |
| Wallet recovery phrase | phone | scrypt + XChaCha20-Poly1305 vault (btc-wallet-security) |
| Wallet history/labels/cache | phone | `EncryptedStorage` with a data key kept in Keychain/Keystore (untested here) |
| AI summaries via gateway | network | HTTPS + redaction (see above) |

Not encrypted by design: data in memory while in use. Anchor `audit.head()` outside the host so end-truncation is detectable.
Never store the master keys on the same disk as `STATE_DIR` in production (use a secret manager/KMS).

## Admin web page (`/admin`)
Enable with `ADMIN_UI=1` (off by default) and restrict with `APPROVER_IPS=["your.ip"]`. Open `https://your-host/admin`, enter your approver id + key.
- Breakers (freeze / resume), pending approvals (second person approves), incidents (acknowledge / close, AI summary), encrypted audit tail.
- Requests are HMAC-signed in the browser with a non-extractable key held in memory only; no cookies, so no CSRF. Auto-locks after 5 minutes idle.
- Strict CSP (own script/style only, no inline code, no framing), all server data rendered with `textContent` (tests assert no HTML-injection sinks and run the real page against the real server).
- Freezing the whole service needs typing STOP and a second person; resume needs two people including an owner.
- Assets live in `src/admin/` and are read at startup (copy that folder if you compile to `dist`).
- Limitation: the key is typed by hand. Passkeys/WebAuthn with per-person accounts are the recommended next step.

## Maximum-protection layer (what is encrypted, and how)
| Layer | Mechanism | Tested |
|---|---|---|
| Transport | TLS 1.3 only; optional **mutual TLS** (client cert CN must equal the key id; untrusted CA/no cert/mismatched CN refused) | yes |
| Request/response bodies | **End-to-end AES-256-GCM** on top of TLS (HKDF key per person/service, envelope bound to route+timestamp+nonce). A TLS-terminating proxy, CDN or log collector sees only ciphertext. The admin page, reporter and owner-app client all do it | yes (page and reporter), owner-app untested |
| State at rest | AES-256-GCM files, 0600, key rotation | yes |
| Audit log | encrypted + hash-chained | yes |
| Master keys | **Encrypted under a passphrase** (scrypt N=2^17 + AES-GCM); never plaintext on disk. `npm run wrap-keys`. Production refuses plain keys | yes |
| Freeze flags | **Sealed + sequence-numbered**: forged, replayed (rollback), deleted or wrongly-keyed flags count as FROZEN; separate FLAG_KEY | yes |
| Requests | HMAC + timestamp + nonce, per-IP/per-key rate limits | yes |
| Supply chain | `.npmrc` (ignore-scripts, exact versions), CI audit, non-root Docker, hardened systemd unit (`deploy/guardian.service`) | not run here |

Cannot be encrypted, only reduced: data in memory while in use; metadata (URL paths, timing, IPs, message sizes);
the passphrase/KMS credential needed at boot. Use a KMS/HSM, encrypted swap or no swap, full-disk encryption, `LimitCORE=0`.

## Vulnerability audit (Nov 2026)
Three-pass audit against 2026 public incidents (weak-RNG seed theft, BIP-143 fee attack, Node.js TLS/HTTP security releases, npm supply chain,
AI prompt injection): see VULNERABILITY-AUDIT.md. The service refuses to start on an unpatched Node.js (`MIN_PATCHED_NODE`, update after every
Node security release), push/chat alerts are generic by default, gateways get masked findings only, and a fuzzing + smuggling + mutation test suite guards every fix.


## Critical freeze-flag integration and rollback protection
All API signing/broadcast services must instantiate `createFrozenGuard(flags)` with a `FlagStore`; passing a directory/plaintext flag path is rejected. The same guard must run before every signing, transaction broadcast, release, and privileged action.

Production `FlagStore` requires `HttpSequenceAnchor`. Configure `FLAG_ANCHOR_URL` and `FLAG_ANCHOR_TOKEN` to a separate HTTPS service implementing:
- `GET /v1/sequence/:name` -> `{"seq": number}`
- `PUT /v1/sequence/:name` with `{"expected": number, "next": number}` -> `{"advanced": boolean}`

The anchor service MUST store values durably and perform atomic compare-and-set, run in a separate account/trust domain, and deny rollback to Guardian operators. Do not implement it as another file or database on the Guardian host. Guardian refuses production startup without it. If the anchor is unavailable, every breaker status fails closed.
