// Matches the "إنذار أمني" artboard. UNTESTED here. Open it from the notification's data.incidentId.
import React, { useEffect, useState } from 'react';
import { I18nManager, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { GuardianClient, BreakerName } from './guardianClient';

I18nManager.allowRTL(true);
const SUGGEST: Record<BreakerName, string> = { SENDS: 'تجميد الإرسال', RELEASES: 'تجميد التحديثات', SERVICE: 'إيقاف الخدمة بالكامل' };

export function AlarmScreen({ client, incidentId }: { client: GuardianClient; incidentId: string }) {
  const [inc, setInc] = useState<any>(null);
  const [msg, setMsg] = useState('');
  useEffect(() => { client.state().then((s) => setInc(s.incidents.find((i) => i.id === incidentId) ?? null)); }, [client, incidentId]);
  if (!inc) return <View style={st.root}><Text style={st.muted}>جارٍ التحميل…</Text></View>;
  const f = inc.findings[0];
  const suggest: BreakerName | undefined = inc.findings.find((x: any) => x.suggest)?.suggest;

  const freeze = async (name: BreakerName) => {
    const p = await client.propose(name, true);
    setMsg(p.done ? `تم: ${SUGGEST[name]}` : 'بانتظار موافقة شخص ثانٍ');
  };
  return (
    <ScrollView contentContainerStyle={st.root}>
      <Text style={st.badge}>إنذار أمني · {inc.severity === 'critical' ? 'حرج' : 'تحذير'}</Text>
      <Text style={st.title}>{f.title}</Text>
      <Text style={st.body}>{f.detail}</Text>
      {inc.aiSummary ? <View style={st.card}><Text style={st.muted}>تحليل الذكاء الاصطناعي (استشاري)</Text><Text style={st.body}>{inc.aiSummary}</Text></View> : null}
      {suggest ? <Pressable accessibilityRole="button" style={st.primary} onPress={() => freeze(suggest)}><Text style={st.primaryTx}>{SUGGEST[suggest]}</Text></Pressable> : null}
      <Pressable accessibilityRole="button" style={st.secondary} onPress={async () => { await client.ack(inc.id); setMsg('تم تأكيد الاستلام'); }}><Text style={st.secondaryTx}>تأكيد الاستلام</Text></Pressable>
      <Pressable accessibilityRole="button" style={st.danger} onPress={() => freeze('SERVICE')}><Text style={st.dangerTx}>إيقاف الخدمة بالكامل (يحتاج موافقة ثانية)</Text></Pressable>
      {msg ? <Text style={st.muted}>{msg}</Text> : null}
    </ScrollView>
  );
}

const st = StyleSheet.create({
  root: { flexGrow: 1, backgroundColor: '#0B0B0D', padding: 20, gap: 14 },
  badge: { color: '#F87171', fontWeight: '800', fontSize: 14 },
  title: { color: '#F4F4F5', fontWeight: '800', fontSize: 26, textAlign: 'right' },
  body: { color: '#D4D4D8', fontSize: 16, lineHeight: 24, textAlign: 'right' },
  muted: { color: '#A1A1AA', fontSize: 14, textAlign: 'right' },
  card: { backgroundColor: '#151518', borderColor: '#26262B', borderWidth: 1, borderRadius: 20, padding: 16, gap: 8 },
  primary: { height: 54, borderRadius: 27, backgroundColor: '#F87171', alignItems: 'center', justifyContent: 'center' },
  primaryTx: { color: '#1A0606', fontWeight: '800', fontSize: 17 },
  secondary: { height: 54, borderRadius: 27, borderWidth: 1, borderColor: '#26262B', backgroundColor: '#151518', alignItems: 'center', justifyContent: 'center' },
  secondaryTx: { color: '#F4F4F5', fontWeight: '700', fontSize: 17 },
  danger: { minHeight: 54, borderRadius: 27, borderWidth: 1, borderColor: '#F87171', alignItems: 'center', justifyContent: 'center', padding: 8 },
  dangerTx: { color: '#F87171', fontWeight: '700', fontSize: 15, textAlign: 'center' },
});
